<?php

$conex = mysqli_connect("localhost","root","Nolase123","registro"); 

?>